import { db } from "./db";
import { roles, permissions, rolePermissions } from "@shared/schema";

const defaultPermissions = [
  // Projects
  { key: "projects.view", displayName: "مشاهده پروژه‌ها", description: "دسترسی به مشاهده لیست پروژه‌ها", category: "projects" },
  { key: "projects.create", displayName: "ایجاد پروژه", description: "ایجاد پروژه جدید", category: "projects" },
  { key: "projects.edit", displayName: "ویرایش پروژه", description: "ویرایش اطلاعات پروژه", category: "projects" },
  { key: "projects.delete", displayName: "حذف پروژه", description: "حذف پروژه", category: "projects" },
  
  // Reports
  { key: "reports.view", displayName: "مشاهده گزارش‌ها", description: "دسترسی به مشاهده گزارش‌ها", category: "reports" },
  { key: "reports.create", displayName: "ثبت گزارش", description: "ثبت گزارش روزانه", category: "reports" },
  { key: "reports.edit", displayName: "ویرایش گزارش", description: "ویرایش گزارش‌ها", category: "reports" },
  
  // Bitumen
  { key: "bitumen.view", displayName: "مشاهده قیر", description: "دسترسی به بخش قیر", category: "bitumen" },
  { key: "bitumen.create", displayName: "ثبت قیر", description: "ثبت رکورد قیر", category: "bitumen" },
  { key: "bitumen.edit", displayName: "ویرایش قیر", description: "ویرایش رکوردهای قیر", category: "bitumen" },
  { key: "bitumen.delete", displayName: "حذف قیر", description: "حذف رکوردهای قیر", category: "bitumen" },
  
  // Sheets (Lab Sheets)
  { key: "sheets.view", displayName: "مشاهده برگه‌های آزمایشگاه", description: "دسترسی به برگه‌های آزمایشگاه", category: "sheets" },
  { key: "sheets.create", displayName: "ثبت برگه آزمایشگاه", description: "ثبت برگه آزمایشگاه جدید", category: "sheets" },
  { key: "sheets.edit", displayName: "ویرایش برگه آزمایشگاه", description: "ویرایش برگه‌های آزمایشگاه", category: "sheets" },
  { key: "sheets.delete", displayName: "حذف برگه آزمایشگاه", description: "حذف برگه‌های آزمایشگاه", category: "sheets" },
  
  // Tenders
  { key: "tenders.view", displayName: "مشاهده مناقصات", description: "دسترسی به مناقصات", category: "tenders" },
  { key: "tenders.create", displayName: "ثبت مناقصه", description: "ثبت مناقصه جدید", category: "tenders" },
  { key: "tenders.edit", displayName: "ویرایش مناقصه", description: "ویرایش مناقصات", category: "tenders" },
  { key: "tenders.delete", displayName: "حذف مناقصه", description: "حذف مناقصات", category: "tenders" },
  
  // Alerts
  { key: "alerts.view", displayName: "مشاهده هشدارها", description: "دسترسی به هشدارها", category: "alerts" },
  { key: "alerts.create", displayName: "ایجاد هشدار", description: "ایجاد هشدار جدید", category: "alerts" },
  { key: "alerts.edit", displayName: "ویرایش هشدار", description: "ویرایش هشدارها", category: "alerts" },
  { key: "alerts.delete", displayName: "حذف هشدار", description: "حذف هشدارها", category: "alerts" },
  
  // Users
  { key: "users.view", displayName: "مشاهده کاربران", description: "دسترسی به لیست کاربران", category: "users" },
  { key: "users.create", displayName: "ایجاد کاربر", description: "ایجاد کاربر جدید", category: "users" },
  { key: "users.edit", displayName: "ویرایش کاربر", description: "ویرایش اطلاعات کاربران", category: "users" },
  { key: "users.delete", displayName: "حذف کاربر", description: "حذف کاربران", category: "users" },
  
  // Roles
  { key: "roles.view", displayName: "مشاهده نقش‌ها", description: "دسترسی به نقش‌ها و مجوزها", category: "roles" },
  { key: "roles.create", displayName: "ایجاد نقش", description: "ایجاد نقش جدید", category: "roles" },
  { key: "roles.edit", displayName: "ویرایش نقش", description: "ویرایش نقش‌ها", category: "roles" },
  { key: "roles.delete", displayName: "حذف نقش", description: "حذف نقش‌ها", category: "roles" },
  
  // Messages
  { key: "messages.view", displayName: "مشاهده پیام‌ها", description: "دسترسی به پیام‌ها", category: "messages" },
  { key: "messages.send", displayName: "ارسال پیام", description: "ارسال پیام", category: "messages" },
  
  // Analysis
  { key: "analysis.view", displayName: "مشاهده تحلیل", description: "دسترسی به تحلیل‌ها", category: "analysis" },
];

const defaultRoles = [
  {
    name: "admin",
    displayName: "مدیر سیستم",
    description: "دسترسی کامل به تمام بخش‌های سیستم",
    isSystem: true,
    permissions: defaultPermissions.map(p => p.key), // All permissions
  },
  {
    name: "manager",
    displayName: "مدیریت",
    description: "مدیریت پروژه‌ها و کاربران",
    isSystem: true,
    permissions: defaultPermissions.map(p => p.key), // All permissions
  },
  {
    name: "project_manager",
    displayName: "مدیر پروژه",
    description: "مدیریت پروژه‌های خاص",
    isSystem: false,
    permissions: [
      "projects.view", "projects.edit",
      "reports.view", "reports.create", "reports.edit",
      "bitumen.view", "bitumen.create", "bitumen.edit",
      "sheets.view", "sheets.create", "sheets.edit",
      "tenders.view",
      "alerts.view", "alerts.create", "alerts.edit",
      "messages.view", "messages.send",
      "analysis.view",
    ],
  },
  {
    name: "technical_office",
    displayName: "دفتر فنی",
    description: "بررسی و تایید برگه‌های آزمایشگاه",
    isSystem: false,
    permissions: [
      "projects.view",
      "reports.view",
      "sheets.view", "sheets.create", "sheets.edit",
      "alerts.view",
      "messages.view", "messages.send",
    ],
  },
  {
    name: "supervisor",
    displayName: "سرپرست",
    description: "نظارت بر پروژه و ثبت گزارش",
    isSystem: false,
    permissions: [
      "projects.view",
      "reports.view", "reports.create",
      "bitumen.view",
      "sheets.view",
      "alerts.view",
      "messages.view", "messages.send",
    ],
  },
  {
    name: "viewer",
    displayName: "بیننده",
    description: "فقط مشاهده اطلاعات",
    isSystem: false,
    permissions: [
      "projects.view",
      "reports.view",
      "bitumen.view",
      "sheets.view",
      "tenders.view",
      "alerts.view",
      "messages.view",
      "analysis.view",
    ],
  },
];

export async function initializePermissionsAndRoles() {
  try {
    console.log("🔐 Initializing permissions and roles...");

    // Check if already initialized
    const existingPerms = await db.select().from(permissions);
    if (existingPerms.length > 0) {
      console.log("✅ Permissions already initialized");
      return;
    }

    // Insert permissions
    const insertedPermissions = await db.insert(permissions).values(defaultPermissions).returning();
    console.log(`✅ Inserted ${insertedPermissions.length} permissions`);

    // Create a map of permission keys to IDs
    const permissionMap = new Map(insertedPermissions.map(p => [p.key, p.id]));

    // Insert roles and their permissions
    for (const roleData of defaultRoles) {
      const { permissions: rolePerms, ...roleInfo } = roleData;
      
      const [role] = await db.insert(roles).values(roleInfo).returning();
      console.log(`✅ Created role: ${role.displayName}`);

      // Assign permissions to role
      const rolePermissionValues = rolePerms
        .map(permKey => {
          const permId = permissionMap.get(permKey);
          return permId ? { roleId: role.id, permissionId: permId } : null;
        })
        .filter(Boolean) as { roleId: string; permissionId: string }[];

      if (rolePermissionValues.length > 0) {
        await db.insert(rolePermissions).values(rolePermissionValues);
        console.log(`   → Assigned ${rolePermissionValues.length} permissions`);
      }
    }

    console.log("✅ Permissions and roles initialized successfully!");
  } catch (error) {
    console.error("❌ Error initializing permissions:", error);
    throw error;
  }
}

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  initializePermissionsAndRoles()
    .then(() => process.exit(0))
    .catch(() => process.exit(1));
}
