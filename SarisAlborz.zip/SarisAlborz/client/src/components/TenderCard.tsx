import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Building2, Calendar, DollarSign, Clock, CheckCircle } from "lucide-react";

interface TenderCardProps {
  id: string;
  title: string;
  city: string;
  amount: string;
  deadline: string;
  organizer: string;
  companies: string[];
  isReviewed: boolean;
  daysUntilDeadline: number;
  onReview?: (id: string) => void;
}

export default function TenderCard({
  id,
  title,
  city,
  amount,
  deadline,
  organizer,
  companies,
  isReviewed,
  daysUntilDeadline,
  onReview,
}: TenderCardProps) {
  const isUrgent = daysUntilDeadline <= 2;

  return (
    <Card className={`hover-elevate ${isUrgent ? 'border-destructive' : ''}`}>
      <CardHeader className="gap-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <h3 className="font-bold truncate" data-testid={`tender-title-${id}`}>{title}</h3>
            <p className="text-sm text-muted-foreground">{city}</p>
          </div>
          <div className="flex gap-2">
            {isReviewed && (
              <Badge variant="secondary">
                <CheckCircle className="w-3 h-3 ml-1" />
                بررسی شده
              </Badge>
            )}
            {isUrgent && (
              <Badge variant="destructive">فوری</Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-muted-foreground" />
            <span>{amount} میلیون ریال</span>
          </div>
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-muted-foreground" />
            <span>{deadline}</span>
          </div>
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-muted-foreground" />
            <span>{organizer}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-muted-foreground" />
            <span className={isUrgent ? 'text-destructive font-medium' : ''}>
              {daysUntilDeadline} روز مانده
            </span>
          </div>
        </div>
        <div>
          <p className="text-xs text-muted-foreground mb-2">شرکت‌های شرکت‌کننده:</p>
          <div className="flex flex-wrap gap-1">
            {companies.map((company, idx) => (
              <Badge key={idx} variant="outline" className="text-xs">
                {company}
              </Badge>
            ))}
          </div>
        </div>
        {!isReviewed && (
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            onClick={() => onReview?.(id)}
            data-testid={`button-review-tender-${id}`}
          >
            ثبت بررسی
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
