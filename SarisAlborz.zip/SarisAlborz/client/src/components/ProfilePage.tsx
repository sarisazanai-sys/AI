import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { User, Mail, Phone, Lock, Upload, Save } from "lucide-react";
import type { User as UserType, Project } from "@shared/schema";

type UserProfile = UserType & {
  projects?: Project[];
  roleInfo?: { displayName: string; description: string } | null;
};

export default function ProfilePage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const currentUser = JSON.parse(localStorage.getItem("user") || "{}");
  const userId = currentUser.id;

  const [profileData, setProfileData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const { data: profile } = useQuery<UserProfile>({
    queryKey: [`/api/profile/${userId}`],
    enabled: !!userId,
  });

  useEffect(() => {
    if (profile) {
      setProfileData({
        firstName: profile.firstName || "",
        lastName: profile.lastName || "",
        email: profile.email || "",
        phone: profile.phone || "",
      });
    }
  }, [profile]);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: typeof profileData) => {
      const response = await fetch(`/api/profile/${userId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("خطا در بروزرسانی پروفایل");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/profile/${userId}`] });
      toast({ title: "پروفایل با موفقیت بروزرسانی شد" });
    },
    onError: () => {
      toast({ title: "خطا در بروزرسانی پروفایل", variant: "destructive" });
    },
  });

  const changePasswordMutation = useMutation({
    mutationFn: async (data: typeof passwordData) => {
      const response = await fetch(`/api/profile/${userId}/change-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "خطا در تغییر رمز عبور");
      }
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "رمز عبور با موفقیت تغییر یافت" });
      setPasswordData({ currentPassword: "", newPassword: "", confirmPassword: "" });
    },
    onError: (error: Error) => {
      toast({ title: error.message, variant: "destructive" });
    },
  });

  const uploadAvatarMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("avatar", file);

      const response = await fetch(`/api/profile/${userId}/avatar`, {
        method: "POST",
        body: formData,
      });
      if (!response.ok) throw new Error("خطا در آپلود تصویر");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/profile/${userId}`] });
      toast({ title: "تصویر پروفایل با موفقیت بروزرسانی شد" });
    },
    onError: () => {
      toast({ title: "خطا در آپلود تصویر", variant: "destructive" });
    },
  });

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({ title: "حجم فایل باید کمتر از 5 مگابایت باشد", variant: "destructive" });
        return;
      }
      uploadAvatarMutation.mutate(file);
    }
  };

  const handleProfileUpdate = () => {
    updateProfileMutation.mutate(profileData);
  };

  const handlePasswordChange = () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({ title: "رمز عبور جدید و تکرار آن مطابقت ندارند", variant: "destructive" });
      return;
    }
    if (passwordData.newPassword.length < 6) {
      toast({ title: "رمز عبور باید حداقل 6 کاراکتر باشد", variant: "destructive" });
      return;
    }
    changePasswordMutation.mutate(passwordData);
  };

  const getInitials = () => {
    if (profile?.firstName && profile?.lastName) {
      return `${profile.firstName.charAt(0)}${profile.lastName.charAt(0)}`;
    }
    if (profile?.username) {
      return profile.username.charAt(0).toUpperCase();
    }
    return "U";
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">پروفایل من</h1>
        <p className="text-muted-foreground mt-2">
          مدیریت اطلاعات شخصی و تنظیمات حساب کاربری
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {/* Avatar and Basic Info Card */}
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>تصویر پروفایل</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center space-y-4">
            <Avatar className="w-32 h-32">
              <AvatarImage src={profile?.avatarPath || undefined} />
              <AvatarFallback className="text-2xl">{getInitials()}</AvatarFallback>
            </Avatar>
            
            <div className="w-full">
              <Label htmlFor="avatar-upload" className="cursor-pointer">
                <div className="flex items-center justify-center gap-2 p-2 border-2 border-dashed rounded-lg hover:bg-accent transition">
                  <Upload className="w-4 h-4" />
                  <span className="text-sm">آپلود تصویر جدید</span>
                </div>
                <Input
                  id="avatar-upload"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleAvatarChange}
                />
              </Label>
              <p className="text-xs text-muted-foreground text-center mt-2">
                حداکثر 5 مگابایت
              </p>
            </div>

            <div className="w-full space-y-2 pt-4 border-t">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">نام کاربری</span>
                <span className="font-medium">{profile?.username}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">نقش</span>
                <Badge variant="secondary">
                  {profile?.roleInfo?.displayName || profile?.role || "کاربر"}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">وضعیت</span>
                <Badge variant={profile?.isActive ? "default" : "destructive"}>
                  {profile?.isActive ? "فعال" : "غیرفعال"}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Personal Information Card */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>اطلاعات شخصی</CardTitle>
            <CardDescription>
              اطلاعات شخصی خود را ویرایش کنید
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">نام</Label>
                <div className="relative">
                  <User className="absolute right-3 top-3 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="firstName"
                    value={profileData.firstName}
                    onChange={(e) =>
                      setProfileData({ ...profileData, firstName: e.target.value })
                    }
                    className="pr-10"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">نام خانوادگی</Label>
                <div className="relative">
                  <User className="absolute right-3 top-3 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="lastName"
                    value={profileData.lastName}
                    onChange={(e) =>
                      setProfileData({ ...profileData, lastName: e.target.value })
                    }
                    className="pr-10"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">ایمیل</Label>
              <div className="relative">
                <Mail className="absolute right-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  value={profileData.email}
                  onChange={(e) =>
                    setProfileData({ ...profileData, email: e.target.value })
                  }
                  className="pr-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">شماره تماس</Label>
              <div className="relative">
                <Phone className="absolute right-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="phone"
                  value={profileData.phone}
                  onChange={(e) =>
                    setProfileData({ ...profileData, phone: e.target.value })
                  }
                  className="pr-10"
                  dir="ltr"
                  placeholder="09123456789"
                />
              </div>
            </div>

            <Button onClick={handleProfileUpdate} className="w-full">
              <Save className="w-4 h-4 ml-2" />
              ذخیره تغییرات
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Change Password Card */}
        <Card>
          <CardHeader>
            <CardTitle>تغییر رمز عبور</CardTitle>
            <CardDescription>
              رمز عبور خود را تغییر دهید
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="currentPassword">رمز عبور فعلی</Label>
              <div className="relative">
                <Lock className="absolute right-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="currentPassword"
                  type="password"
                  value={passwordData.currentPassword}
                  onChange={(e) =>
                    setPasswordData({ ...passwordData, currentPassword: e.target.value })
                  }
                  className="pr-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="newPassword">رمز عبور جدید</Label>
              <div className="relative">
                <Lock className="absolute right-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="newPassword"
                  type="password"
                  value={passwordData.newPassword}
                  onChange={(e) =>
                    setPasswordData({ ...passwordData, newPassword: e.target.value })
                  }
                  className="pr-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">تکرار رمز عبور جدید</Label>
              <div className="relative">
                <Lock className="absolute right-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  id="confirmPassword"
                  type="password"
                  value={passwordData.confirmPassword}
                  onChange={(e) =>
                    setPasswordData({ ...passwordData, confirmPassword: e.target.value })
                  }
                  className="pr-10"
                />
              </div>
            </div>

            <Button onClick={handlePasswordChange} className="w-full" variant="secondary">
              <Lock className="w-4 h-4 ml-2" />
              تغییر رمز عبور
            </Button>
          </CardContent>
        </Card>

        {/* Projects Card */}
        <Card>
          <CardHeader>
            <CardTitle>پروژه‌های تخصیص یافته</CardTitle>
            <CardDescription>
              پروژه‌هایی که به شما اختصاص داده شده است
            </CardDescription>
          </CardHeader>
          <CardContent>
            {profile?.projects && profile.projects.length > 0 ? (
              <div className="space-y-2">
                {profile.projects.map((project) => (
                  <div
                    key={project.id}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div>
                      <p className="font-medium">{project.title}</p>
                      <p className="text-sm text-muted-foreground">{project.location}</p>
                    </div>
                    <Badge variant="outline">{project.status}</Badge>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">
                هیچ پروژه‌ای به شما اختصاص داده نشده است
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
