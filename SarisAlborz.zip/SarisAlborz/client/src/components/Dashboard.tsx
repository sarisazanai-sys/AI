import DashboardCard from "./DashboardCard";
import ProjectCard from "./ProjectCard";
import AlertCard from "./AlertCard";
import { FolderKanban, FileText, Users, DollarSign } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import type { Project } from "@shared/schema";
import { useProject } from "@/lib/project-context";
import { useLocation } from "wouter";

export default function Dashboard() {
  const { data: projects = [], isLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const response = await fetch("/api/projects");
      if (!response.ok) throw new Error("خطا در دریافت پروژه‌ها");
      return response.json();
    },
  });

  const [, setLocation] = useLocation();

  const handleViewDetails = (id: string) => {
    setLocation(`/projects/${id}`);
  };

  //todo: remove mock functionality
  const mockAlerts = [
    {
      id: "1",
      title: "گزارش روزانه تایید شد",
      message: "گزارش روزانه پروژه آزادراه تهران-شمال مورخ 1402/10/15 توسط مدیر پروژه تایید شد.",
      type: "success" as const,
      project: "آزادراه تهران-شمال",
      date: "1402/10/15 - 14:30",
      isRead: false,
    },
    {
      id: "2",
      title: "هشدار تاخیر در پروژه",
      message: "پروژه بزرگراه صیاد شیرازی با تاخیر 5 روزه مواجه است.",
      type: "warning" as const,
      project: "بزرگراه صیاد شیرازی",
      date: "1402/10/14 - 09:15",
      isRead: false,
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">داشبورد</h1>
        <p className="text-muted-foreground">خلاصه وضعیت پروژه‌ها و فعالیت‌ها</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <DashboardCard
          title="پروژه‌های فعال"
          value="12"
          icon={FolderKanban}
          description="پروژه در حال اجرا"
          trend={{ value: 8, isPositive: true }}
        />
        <DashboardCard
          title="گزارش‌های روزانه"
          value="145"
          icon={FileText}
          description="این ماه"
          trend={{ value: 12, isPositive: true }}
        />
        <DashboardCard
          title="کاربران فعال"
          value="28"
          icon={Users}
          description="کاربر آنلاین"
        />
        <DashboardCard
          title="مجموع قراردادها"
          value="۲۴۵ میلیارد"
          icon={DollarSign}
          description="ریال"
          trend={{ value: 5, isPositive: true }}
        />
      </div>

      <Tabs defaultValue="projects" className="w-full">
        <TabsList className="grid w-full grid-cols-2 max-w-md">
          <TabsTrigger value="projects" data-testid="tab-projects">پروژه‌های اخیر</TabsTrigger>
          <TabsTrigger value="alerts" data-testid="tab-alerts">هشدارها</TabsTrigger>
        </TabsList>
        
        <TabsContent value="projects" className="mt-6">
          {isLoading ? (
            <div className="text-center text-muted-foreground py-8">در حال بارگذاری...</div>
          ) : projects.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">هنوز پروژه‌ای ثبت نشده است</div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {projects.map((project) => (
                <ProjectCard
                  key={project.id}
                  {...project}
                  onViewDetails={handleViewDetails}
                />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="alerts" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>هشدارهای اخیر</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {mockAlerts.map((alert) => (
                <AlertCard
                  key={alert.id}
                  {...alert}
                  onMarkRead={(id) => console.log("Mark alert as read:", id)}
                />
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
