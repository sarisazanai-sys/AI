import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import ThemeToggle from "@/components/ThemeToggle";
import { Button } from "@/components/ui/button";
import { LogOut, Calendar } from "lucide-react";
import Dashboard from "@/components/Dashboard";
import ProjectsPage from "@/components/ProjectsPage";
import ProjectDetailsPage from "@/pages/ProjectDetailsPage";
import ReportsPage from "@/components/ReportsPage";
import ExecutionReportsPage from "@/pages/ExecutionReportsPage";
import BitumenPage from "@/components/BitumenPage";
import TendersPage from "@/components/TendersPage";
import AlertsPage from "@/components/AlertsPage";
import UsersPage from "@/components/UsersPage";
import MessagesPage from "@/components/MessagesPage";
import SheetsPage from "@/components/SheetsPage";
import RolesPage from "@/components/RolesPage";
import ProfilePage from "@/components/ProfilePage";
import LoginForm from "@/components/LoginForm";
import NotFound from "@/pages/not-found";
import { useState, useEffect } from "react";
import { format } from "date-fns-jalali";
import { toPersianDigits } from "@/lib/persian-utils";
import { ProjectProvider } from "@/lib/project-context";

function PersianDate() {
  const [currentDate, setCurrentDate] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDate(new Date());
    }, 60000); // Update every minute

    return () => clearInterval(timer);
  }, []);

  const persianWeekDays = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه', 'شنبه'];
  const dayName = persianWeekDays[currentDate.getDay()];
  const formattedDate = toPersianDigits(format(currentDate, 'yyyy/MM/dd'));

  return (
    <div className="flex items-center gap-2 text-sm text-muted-foreground">
      <Calendar className="w-4 h-4" />
      <span className="hidden sm:inline">{dayName}</span>
      <span>{formattedDate}</span>
    </div>
  );
}

function AuthenticatedRoutes() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/projects" component={ProjectsPage} />
      <Route path="/projects/:id" component={ProjectDetailsPage} />
      <Route path="/reports/execution" component={ExecutionReportsPage} />
      <Route path="/reports/technical" component={ReportsPage} />
      <Route path="/reports" component={ReportsPage} />
      <Route path="/bitumen" component={BitumenPage} />
      <Route path="/sheets" component={SheetsPage} />
      <Route path="/tenders" component={TendersPage} />
      <Route path="/alerts" component={AlertsPage} />
      <Route path="/analysis">
        <div className="p-6">
          <h1 className="text-3xl font-bold mb-4">تحلیل پروژه</h1>
          <p className="text-muted-foreground">نمودارها و تحلیل‌های مالی</p>
        </div>
      </Route>
      <Route path="/users" component={UsersPage} />
      <Route path="/roles" component={RolesPage} />
      <Route path="/profile" component={ProfilePage} />
      <Route path="/messages" component={MessagesPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return !!localStorage.getItem("user");
  });
  
  const style = {
    "--sidebar-width": "20rem",
    "--sidebar-width-icon": "4rem",
  };

  const handleLogin = async (username: string, password: string) => {
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      if (!response.ok) {
        const error = await response.json();
        alert(error.message || "خطا در ورود");
        return;
      }

      const userData = await response.json();
      localStorage.setItem("user", JSON.stringify(userData));
      setIsAuthenticated(true);
    } catch (error) {
      alert("خطا در ارتباط با سرور");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("user");
    setIsAuthenticated(false);
  };

  const currentUser = JSON.parse(localStorage.getItem("user") || "{}");
  const displayName = currentUser.firstName && currentUser.lastName 
    ? `${currentUser.firstName} ${currentUser.lastName}` 
    : currentUser.username || "کاربر";
  const userRole = currentUser.role || "کاربر سیستم";

  return (
    <QueryClientProvider client={queryClient}>
      <ProjectProvider>
        <TooltipProvider>
          {!isAuthenticated ? (
            <LoginForm onLogin={() => setIsAuthenticated(true)} />
          ) : (
            <SidebarProvider style={style as React.CSSProperties}>
              <div className="flex h-screen w-full">
                <div className="flex flex-col flex-1">
                  <header className="flex items-center justify-between p-4 border-b gap-4">
                    <div className="flex items-center gap-2">
                      <ThemeToggle />
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => setIsAuthenticated(false)}
                        data-testid="button-logout"
                      >
                        <LogOut className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="flex items-center gap-4">
                      <SidebarTrigger data-testid="button-sidebar-toggle" />
                      <h2 className="font-semibold hidden md:block">سیستم مدیریت پروژه</h2>
                      <div className="hidden md:block h-6 w-px bg-border"></div>
                      <PersianDate />
                    </div>
                  </header>
                  <main className="flex-1 overflow-auto p-6">
                    <AuthenticatedRoutes />
                  </main>
                </div>
                <AppSidebar currentUser={currentUser} />
              </div>
            </SidebarProvider>
          )}
          <Toaster />
        </TooltipProvider>
      </ProjectProvider>
    </QueryClientProvider>
  );
}

export default App;
