# سریع‌سازان البرز - سیستم مدیریت پروژه

## Overview
This project is a comprehensive construction project management application developed in Farsi. Its primary purpose is to streamline project tracking, material management, tendering processes, and internal communication for construction firms. Key capabilities include:
- Managing construction projects and monitoring progress.
- Tracking bitumen and other construction materials.
- Daily reporting and execution progress tracking.
- Tender management with automated SLA alerts.
- An analytical dashboard for insights.
- An internal messaging system for direct, group, and project-specific communications.

The ambition is to provide a robust, localized solution for construction project management in Farsi-speaking markets, enhancing efficiency and communication.

## User Preferences
- All user interface elements and content should be in Farsi.
- The application should utilize the Jalali (Persian) calendar system for all date-related functionalities.
- The default currency for all financial transactions and displays should be Iranian Rial (ریال).
- The user interface design must support Right-to-Left (RTL) directionality consistently across all components.

## System Architecture

### UI/UX Decisions
- **Language & Direction**: Farsi language with RTL layout.
- **Date & Currency**: Jalali calendar and Iranian Rial.
- **Components**: Utilizes Radix UI and shadcn/ui for a modern and accessible design system.
- **Design Approach**: Focus on clear, intuitive navigation and data presentation, especially for complex features like tender management and alerts.

### Technical Implementations
- **Frontend**: Developed with React, Vite, TypeScript, and styled using Tailwind CSS. State management is handled by TanStack Query (React Query).
- **Backend**: Built with Express.js and TypeScript, providing a robust API layer.
- **Database**: PostgreSQL, managed with Drizzle ORM and the `pg` driver for local Replit environments.
- **File Uploads**: `multer` is used for handling file attachments in both the messaging system and lab sheets module, storing them in structured directories:
  - Messages: `/uploads/messages/{conversation_id}/{message_id}/`
  - Lab Sheets: `/uploads/sheets/{project_id}/{sheet_id}/`
- **Real-time Updates**: Hot Module Replacement (HMR) is configured for seamless development.

### Feature Specifications
- **Project Management**: CRUD operations for projects, progress tracking, search, and filtering.
- **Material Management (Bitumen)**: Project-specific bitumen record management with CSV export.
- **Tender Management**: Comprehensive CRUD for tenders, automated SLA alerts (e.g., "Deadline approaching," "Needs review," "Expired"), intelligent sorting, and status tracking.
- **Alert Management**: Centralized alert listing, advanced filtering, manual alert creation, status changes, user assignment, and CSV export. Automated alerts are generated hourly for overdue tenders, nearing tender deadlines, and underperforming projects.
- **Lab Sheets Management**:
    - CRUD operations for laboratory test sheets.
    - Multiple sheet types: Quality Control, Material Testing, Soil Testing, Concrete Testing, Asphalt Testing.
    - File attachment support (up to 5 files per sheet: images, PDFs, Excel, Word documents).
    - Advanced filtering by project, sheet type, status, and date range.
    - Status tracking: Pending, Approved, Rejected.
    - CSV export functionality.
    - Soft delete (sheets are archived, not permanently removed).
    - File storage: `/uploads/sheets/{project_id}/{sheet_id}/`.
- **Internal Messaging System**:
    - Supports Direct, Group, and Project-specific conversations.
    - Text and file attachment (up to 5 files) messaging.
    - Read/unread status tracking.
    - Message search functionality.
    - Member management within conversations.
    - RTL UI with chat mode and conversation list.
- **Reporting**: Daily activity reports and execution progress reports.

### System Design Choices
- **Monorepo Structure**: The project is organized into `client/`, `server/`, and `shared/` directories to promote code reuse and maintainability.
- **Database Schema**:
    - `users`: System users with authentication, roles, and avatar support (`avatarPath` field added).
    - `projects`: Construction projects.
    - `bitumen_records`: Bitumen and material records.
    - `tenders`: Tenders and business opportunities.
    - `alerts`: Project-related alerts with severity, status, and assignment tracking.
    - `user_projects`: N:M relationship between users and projects with `assignedBy` tracking.
    - `sheets`: Laboratory test sheets with project association, sheet type, dates, location, lab info, status, and soft delete support.
    - `sheet_files`: File attachments for lab sheets with metadata (file name, path, type, uploader).
    - `conversations`: Messaging conversations (direct/group/project).
    - `conversation_members`: Members of conversations with `isAdmin` flag for group management.
    - `messages`: Sent messages with file attachment support.
    - `message_files`: Message attachments metadata.
    - `message_reads`: Message read status tracking.
- **Integrated Server**: The Express server serves both API endpoints and frontend assets, running on port 5000.
- **Automated Tasks**: Scheduled tasks (e.g., hourly checks for alerts) are integrated into the backend logic.

## External Dependencies
- **Database**: PostgreSQL (local Replit instance).
- **ORM**: Drizzle ORM.
- **Node.js Driver**: `pg` (for PostgreSQL interaction).
- **Frontend Libraries**: React, Vite, TypeScript, Tailwind CSS, Radix UI, shadcn/ui, TanStack Query (React Query).
- **Backend Libraries**: Express.js, TypeScript.
- **File Upload Middleware**: `multer`.

## Replit Environment Setup (Updated: October 7, 2025)

### Initial Setup
1. **Programming Languages**: Node.js 20 installed successfully.
2. **Database**: PostgreSQL database is provisioned and connected via `DATABASE_URL` environment variable.
3. **Dependencies**: All npm packages installed successfully.
4. **Database Schema**: Pushed using `npm run db:push` command - all tables created successfully.

### Running the Application
- **Development Server**: Runs on port 5000 (both API and frontend)
  - Command: `npm run dev`
  - Workflow configured and running successfully
- **Production Build**: 
  - Build: `npm run build`
  - Start: `npm start`

### Deployment Configuration
- **Target**: Autoscale (stateless website)
- **Build Command**: `npm run build`
- **Run Command**: `npm start`

### Verified Features
- ✓ Login page loads correctly with Farsi RTL layout
- ✓ Auto-alert scheduler running (hourly checks)
- ✓ Vite HMR configured for Replit proxy
- ✓ All host headers configured correctly (`allowedHosts: true`)
- ✓ WebSocket HMR on port 443 with WSS protocol
- ✓ Application fully functional on port 5000

### Important Notes
- The application serves both frontend and backend on a single port (5000) as designed.
- Vite dev server runs on port 5173 internally but is proxied through Express on port 5000.
- Database migrations are handled via Drizzle Kit (`npm run db:push`).
- GitHub import successfully completed and configured for Replit environment.

### Test Credentials
- **Admin User**:
  - Username: `admin`
  - Password: `admin123`
  - Role: مدیر سیستم (System Admin)
  - Email: admin@sari-sazan.ir

## Recent Changes (October 7, 2025)

### Roles & Permissions System Implementation
- **New Feature**: Complete role-based access control system
- **Database Tables**:
  - `roles`: User roles with system/custom flag
  - `permissions`: Granular permissions for all system features
  - `role_permissions`: M:N relationship between roles and permissions
- **Default Roles & Permissions**:
  - 6 predefined roles: Admin (34 perms), Management (34 perms), Project Manager (18 perms), Technical Office (8 perms), Supervisor (8 perms), Viewer (8 perms)
  - 34 permissions across 9 categories: projects, reports, bitumen, sheets, tenders, alerts, users, roles, messages, analysis
  - Auto-initialization on server startup (server/init-permissions.ts)
- **API Endpoints** (server/routes.ts):
  - GET `/api/roles` - List all roles
  - GET `/api/roles/:id` - Get role with permissions
  - POST `/api/roles` - Create custom role
  - PUT `/api/roles/:id` - Update role
  - DELETE `/api/roles/:id` - Delete custom role
  - GET `/api/permissions` - List all permissions
  - PUT `/api/roles/:id/permissions` - Update role permissions
  - GET `/api/profile` - Get current user profile
  - PUT `/api/profile` - Update profile info
  - POST `/api/profile/avatar` - Upload avatar (multer)
  - PUT `/api/profile/password` - Change password
- **Frontend Components**:
  - RolesPage.tsx: Complete roles & permissions management UI
  - ProfilePage.tsx: User profile with avatar upload, info edit, password change
- **Routes**: `/roles` and `/profile` added to App.tsx
- **File Storage**: User avatars stored in `/uploads/avatars/{user_id}/`

## Recent Changes (October 6, 2025)

### Lab Sheets Module Implementation
- **New Feature**: Complete laboratory test sheets management system
- **Database Tables**:
  - `sheets`: Main table with nullable `createdBy` (allows user deletion without data loss)
  - `sheet_files`: File attachments with nullable `uploadedBy`
- **API Endpoints** (server/routes.ts):
  - GET `/api/sheets` - List with filters (project, type, status, date range)
  - GET `/api/sheets/:id` - Get single sheet with files
  - POST `/api/sheets` - Create with file uploads (max 5 files, 15MB each)
  - PUT `/api/sheets/:id` - Update sheet metadata
  - DELETE `/api/sheets/:id` - Soft delete
  - GET `/api/sheets/csv` - Export to CSV
  - GET `/api/sheets/files/:fileId` - Download file
- **Frontend**: SheetsPage.tsx component with comprehensive UI
  - RTL layout with Farsi labels
  - Advanced filtering (project, type, status, date range)
  - Create/Edit dialog with file upload
  - Jalali calendar date pickers
  - Table view with inline actions
- **File Support**: JPG, PNG, PDF, Excel (.xlsx, .xls), Word (.doc, .docx)
- **Route**: `/sheets` added to App.tsx

### Messaging Module Update
- **Renamed**: Changed all references from "اینباکس" (Inbox) to "پیام‌ها" (Messages) throughout the application
- **Route Updated**: Changed route from `/inbox` to `/messages` for better consistency
- **UI Updates**: Updated sidebar menu and navigation to reflect the new naming

### Database Schema Enhancements
The following fields were added to the database schema to support enhanced functionality:

1. **users table**:
   - Added `avatarPath` field for user profile picture support

2. **user_projects table**:
   - Added `assignedBy` field to track which user assigned a project to another user

3. **conversation_members table**:
   - Added `isAdmin` field to support group conversation administration

All schema changes have been successfully pushed to the database and are fully operational.