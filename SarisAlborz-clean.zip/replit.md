# سریع‌سازان البرز - سیستم مدیریت پروژه

## Overview
This project is a comprehensive construction project management application developed in Farsi. Its primary purpose is to streamline project tracking, material management, tendering processes, and internal communication for construction firms. Key capabilities include managing construction projects, tracking materials like bitumen, daily reporting, tender management with SLA alerts, an analytical dashboard, and an internal messaging system. The ambition is to provide a robust, localized solution for construction project management in Farsi-speaking markets, enhancing efficiency and communication.

## User Preferences
- All user interface elements and content should be in Farsi.
- The application should utilize the Jalali (Persian) calendar system for all date-related functionalities.
- The default currency for all financial transactions and displays should be Iranian Rial (ریال).
- The user interface design must support Right-to-Left (RTL) directionality consistently across all components.

## System Architecture

### UI/UX Decisions
- **Language & Direction**: Farsi language with RTL layout.
- **Date & Currency**: Jalali calendar and Iranian Rial.
- **Components**: Utilizes Radix UI and shadcn/ui for a modern and accessible design system.
- **Design Approach**: Focus on clear, intuitive navigation and data presentation, especially for complex features like tender management and alerts.

### Technical Implementations
- **Frontend**: Developed with React, Vite, TypeScript, and styled using Tailwind CSS. State management is handled by TanStack Query (React Query).
- **Backend**: Built with Express.js and TypeScript, providing a robust API layer.
- **Database**: PostgreSQL, managed with Drizzle ORM.
- **File Uploads**: `multer` is used for handling file attachments in messaging and lab sheets.
- **Real-time Updates**: Hot Module Replacement (HMR) is configured for seamless development.

### Feature Specifications
- **Project Management**: CRUD operations, progress tracking, search, and filtering.
- **Material Management (Bitumen)**: Project-specific bitumen record management with CSV export.
- **Progress Statements (صورت‌وضعیت‌ها)**: Three-tab interface for Statements, Adjustments, and Bitumen Differences with CRUD, project-based filtering, status tracking (تأیید شده, ابلاغ شده, در انتظار, حذف‌شده, اصلاح‌شده), financial calculation, soft delete, and support for negative amounts.
- **Tender Management**: Comprehensive CRUD for tenders, automated SLA alerts, intelligent sorting, and status tracking.
- **Alert Management**: Centralized listing, advanced filtering, manual creation, status changes, user assignment, and CSV export. Automated hourly alerts for overdue tenders, nearing deadlines, and underperforming projects.
- **Lab Sheets Management**: CRUD for various sheet types (Quality Control, Material Testing, etc.), file attachment support (up to 5 files), advanced filtering, status tracking, CSV export, and soft delete.
- **Internal Messaging System**: Supports Direct, Group, and Project-specific conversations with text, file attachments, read/unread status, search, and member management.
- **Reporting**: Daily activity reports and execution progress reports.
- **Roles & Permissions**: Role-based access control with predefined and custom roles, granular permissions, and user profile management including avatar uploads.

### System Design Choices
- **Monorepo Structure**: Organized into `client/`, `server/`, and `shared/` directories.
- **Database Schema**: Includes `users` (with `avatarPath`), `projects` (with contract details), `bitumen_records`, `statements`, `adjustments`, `bitumen_diffs`, `tenders`, `alerts`, `user_projects` (with `assignedBy`), `sheets`, `sheet_files`, `conversations`, `conversation_members` (with `isAdmin`), `messages`, `message_files`, `message_reads`.
- **Integrated Server**: Express server serves both API endpoints and frontend assets on port 5000.
- **Automated Tasks**: Scheduled tasks (e.g., hourly checks for alerts) integrated into the backend.

## External Dependencies
- **Database**: PostgreSQL.
- **ORM**: Drizzle ORM.
- **Node.js Driver**: `pg` (for PostgreSQL).
- **Frontend Libraries**: React, Vite, TypeScript, Tailwind CSS, Radix UI, shadcn/ui, TanStack Query (React Query).
- **Backend Libraries**: Express.js, TypeScript.
- **File Upload Middleware**: `multer`.

## Replit Setup & Configuration

### Environment Setup (Completed)
- **Runtime**: Node.js 20
- **Database**: PostgreSQL database provisioned with environment variables (DATABASE_URL, PGHOST, PGUSER, PGPASSWORD, PGDATABASE, PGPORT)
- **Database Schema**: Initialized via Drizzle ORM with `npm run db:push`

### Development Workflow
- **Command**: `npm run dev`
- **Port**: 5000 (serves both API and frontend)
- **Vite Configuration**: Already configured with `allowedHosts: true` for Replit proxy support
- **HMR**: WebSocket configured for HTTPS (wss protocol on port 443)

### Deployment Configuration
- **Deployment Type**: VM (maintains server state, websockets, scheduled tasks)
- **Build Command**: `npm run build` (builds frontend with Vite, backend with esbuild)
- **Start Command**: `npm run start` (runs production server on port 5000)

### Initial Setup Notes
- Permissions and roles are auto-initialized on first server start
- Auto-alert scheduler runs hourly to check for tender deadlines and project alerts
- Project imported from GitHub and successfully configured for Replit environment
- Import cleanup completed: removed duplicate AI/ directory and archive files

### Project Import (October 8, 2025)
- Successfully imported project from GitHub repository (delivered as ZIP archive)
- Extracted and moved all files to root directory
- Installed Node.js 20 runtime and all project dependencies
- Database already provisioned, schema initialized successfully via Drizzle
- Development workflow configured on port 5000
- Application verified and running correctly with Farsi RTL interface
- VM deployment configured for production with build and start commands
- Import completed successfully and all systems operational

## Recent Changes (October 2025)

### Performance Optimizations
**Critical Bug Fixes:**
- Fixed server crash issue in `server/vite.ts` where custom Vite logger was calling `process.exit(1)` on any error, causing silent server crashes
- Removed destructive error handler to prevent Node process termination on Vite compilation errors

**Component Performance Enhancements:**
All major data-heavy components optimized with React `useMemo` hooks to prevent expensive recalculations on every render:
- **StatementsPage**: Optimized filter, sort, reduce operations for statements, adjustments, and bitumen differences
- **AlertsPage**: Optimized alert filtering across multiple dimensions (search, status, severity, project)
- **TendersPage**: Optimized tender filtering and deadline-based sorting
- **BitumenPage**: Optimized record filtering, totals calculations, and vendor/type arrays
- **SheetsPage**: Optimized sheet filtering by search query

These optimizations significantly improve UI responsiveness, especially when dealing with large datasets or frequent state updates (e.g., typing in search fields, changing filters).