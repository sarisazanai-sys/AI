import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Image as ImageIcon, Send } from "lucide-react";

export default function DailyReportForm({ onSubmit }: { onSubmit?: (data: any) => void }) {
  const [formData, setFormData] = useState({
    projectId: "",
    date: "",
    temperature: "",
    materials: "",
    description: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Daily report submitted:", formData);
    onSubmit?.(formData);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>ثبت گزارش روزانه</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="project">پروژه *</Label>
            <Select
              value={formData.projectId}
              onValueChange={(value) => setFormData({ ...formData, projectId: value })}
            >
              <SelectTrigger id="project" data-testid="select-project">
                <SelectValue placeholder="انتخاب پروژه" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">پروژه آزادراه تهران-شمال</SelectItem>
                <SelectItem value="2">پروژه بزرگراه صیاد شیرازی</SelectItem>
                <SelectItem value="3">پروژه راه آهن تبریز</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date">تاریخ *</Label>
              <div className="relative">
                <Input
                  id="date"
                  type="text"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  placeholder="1402/10/15"
                  data-testid="input-date"
                />
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="temperature">دمای هوا (°C)</Label>
              <Input
                id="temperature"
                type="number"
                value={formData.temperature}
                onChange={(e) => setFormData({ ...formData, temperature: e.target.value })}
                placeholder="25"
                data-testid="input-temperature"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="materials">مصالح مصرفی</Label>
            <Input
              id="materials"
              value={formData.materials}
              onChange={(e) => setFormData({ ...formData, materials: e.target.value })}
              placeholder="مثال: قیر 100 تن، آسفالت 200 تن"
              data-testid="input-materials"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">توضیحات</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="توضیحات تکمیلی..."
              rows={4}
              data-testid="input-description"
            />
          </div>

          <div className="space-y-2">
            <Label>عکس‌های گزارش</Label>
            <div className="border-2 border-dashed border-border rounded-md p-6 text-center hover-elevate cursor-pointer">
              <ImageIcon className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">برای آپلود عکس کلیک کنید</p>
            </div>
          </div>

          <Button type="submit" className="w-full" data-testid="button-submit-report">
            <Send className="w-4 h-4 ml-2" />
            ثبت گزارش
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
