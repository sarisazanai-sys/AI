import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Search } from "lucide-react";
import { format } from "date-fns-jalali";
import { toPersianDigits } from "@/lib/persian-utils";

export function ExecutionReportList() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedProject, setSelectedProject] = useState<string>("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [startDatePersian, setStartDatePersian] = useState("");
  const [endDatePersian, setEndDatePersian] = useState("");

  const { data: projects } = useQuery({
    queryKey: ["projects"],
    queryFn: async () => {
      const response = await fetch("/api/projects");
      if (!response.ok) throw new Error("Failed to fetch projects");
      return response.json();
    },
  });

  const { data: reports, isLoading } = useQuery({
    queryKey: ["execution-reports", selectedProject, startDate, endDate, searchTerm],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedProject && selectedProject !== "all") params.append("projectId", selectedProject);
      if (startDate) params.append("startDate", startDate);
      if (endDate) params.append("endDate", endDate);
      if (searchTerm) params.append("search", searchTerm);

      const response = await fetch(`/api/reports/execution?${params.toString()}`);
      if (!response.ok) throw new Error("Failed to fetch reports");
      return response.json();
    },
  });

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return toPersianDigits(format(date, 'yyyy/MM/dd'));
  };

  const getWeatherLabel = (condition: string) => {
    const labels: Record<string, string> = {
      sunny: "آفتابی",
      cloudy: "ابری",
      rainy: "بارانی",
      snowy: "برفی",
      stormy: "طوفانی",
    };
    return labels[condition] || condition;
  };

  return (
    <div className="space-y-4" dir="rtl">
      <Card>
        <CardHeader>
          <CardTitle>فیلترها</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label htmlFor="search">جست‌وجو</Label>
              <div className="relative">
                <Search className="absolute right-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="search"
                  placeholder="جست‌وجو در فعالیت‌ها..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10 text-right"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="project">پروژه</Label>
              <Select value={selectedProject} onValueChange={setSelectedProject}>
                <SelectTrigger id="project">
                  <SelectValue placeholder="همه پروژه‌ها" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه پروژه‌ها</SelectItem>
                  {projects?.map((project: any) => (
                    <SelectItem key={project.id} value={project.id}>
                      {project.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="startDate">از تاریخ</Label>
              <Input
                id="startDate"
                type="text"
                value={startDatePersian}
                onChange={(e) => setStartDatePersian(e.target.value)}
                placeholder="۱۴۰۴/۰۷/۰۱"
                className="text-right"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="endDate">تا تاریخ</Label>
              <Input
                id="endDate"
                type="text"
                value={endDatePersian}
                onChange={(e) => setEndDatePersian(e.target.value)}
                placeholder="۱۴۰۴/۰۷/۳۰"
                className="text-right"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>لیست گزارش‌های اجرا</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">در حال بارگذاری...</div>
          ) : reports?.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              هیچ گزارشی یافت نشد
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">تاریخ</TableHead>
                    <TableHead className="text-right">پروژه</TableHead>
                    <TableHead className="text-right">سرپرست</TableHead>
                    <TableHead className="text-right">آب‌وهوا</TableHead>
                    <TableHead className="text-right">دما (°C)</TableHead>
                    <TableHead className="text-right">فعالیت</TableHead>
                    <TableHead className="text-right">ماشین‌آلات</TableHead>
                    <TableHead className="text-right">سرویس/تناژ</TableHead>
                    <TableHead className="text-right">بازدید</TableHead>
                    <TableHead className="text-right">مشکلات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reports?.map((report: any) => (
                    <TableRow key={report.id}>
                      <TableCell className="text-right">
                        {formatDate(report.reportDate)}
                      </TableCell>
                      <TableCell className="text-right">
                        {report.project?.name || "-"}
                      </TableCell>
                      <TableCell className="text-right">
                        {report.supervisor?.username || "-"}
                      </TableCell>
                      <TableCell className="text-right">
                        {getWeatherLabel(report.weatherCondition)}
                      </TableCell>
                      <TableCell className="text-right">
                        {toPersianDigits(report.minTemperature)}° / {toPersianDigits(report.maxTemperature)}°
                      </TableCell>
                      <TableCell className="text-right max-w-xs truncate">
                        {report.activityDescription}
                      </TableCell>
                      <TableCell className="text-right">
                        {report.machinery?.length > 0 ? (
                          <div className="space-y-1">
                            {report.machinery.map((m: any, i: number) => (
                              <div key={i} className="text-sm">
                                {m.machineryName} × {toPersianDigits(m.count)}
                              </div>
                            ))}
                          </div>
                        ) : (
                          "-"
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        {report.materials?.length > 0 ? (
                          <div className="space-y-1">
                            {report.materials.map((m: any, i: number) => (
                              <div key={i} className="text-sm">
                                {m.materialType}: {toPersianDigits(m.serviceCount)} سرویس / {toPersianDigits(m.tonnage)} تن
                              </div>
                            ))}
                          </div>
                        ) : (
                          "-"
                        )}
                      </TableCell>
                      <TableCell className="text-right max-w-xs truncate">
                        {report.inspectionDescription || "-"}
                      </TableCell>
                      <TableCell className="text-right max-w-xs truncate">
                        {report.existingProblems || "-"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
