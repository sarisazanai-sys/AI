import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Calendar, DollarSign, MapPin, ArrowLeft } from "lucide-react";

interface ProjectCardProps {
  id: string;
  title: string;
  contractNumber: string | null;
  location: string | null;
  employer: string | null;
  amount: string | null;
  progress: number | null;
  status: string | null;
  startDate: string | null;
  onViewDetails?: (id: string) => void;
}

const statusLabels: Record<string, string> = {
  active: "در حال اجرا",
  completed: "تکمیل شده",
  pending: "در انتظار",
  suspended: "متوقف شده",
};

const statusVariants: Record<string, "default" | "outline" | "destructive"> = {
  active: "default" as const,
  completed: "default" as const,
  pending: "outline" as const,
  suspended: "destructive" as const,
};

export default function ProjectCard({
  id,
  title,
  contractNumber,
  location,
  employer,
  amount,
  progress,
  status,
  startDate,
  onViewDetails,
}: ProjectCardProps) {
  return (
    <Card className="hover-elevate transition-all">
      <CardHeader className="gap-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-lg truncate" data-testid={`project-title-${id}`}>{title}</h3>
            <p className="text-sm text-muted-foreground">شماره قرارداد: {contractNumber || "نامشخص"}</p>
          </div>
          <Badge variant={statusVariants[status || "active"]} data-testid={`project-status-${id}`}>
            {statusLabels[status || "active"]}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          {location && (
            <div className="flex items-center gap-2 text-sm">
              <MapPin className="w-4 h-4 text-muted-foreground" />
              <span>{location}</span>
            </div>
          )}
          {amount && (
            <div className="flex items-center gap-2 text-sm">
              <DollarSign className="w-4 h-4 text-muted-foreground" />
              <span>{amount} ریال</span>
            </div>
          )}
          {startDate && (
            <div className="flex items-center gap-2 text-sm">
              <Calendar className="w-4 h-4 text-muted-foreground" />
              <span>شروع: {startDate}</span>
            </div>
          )}
        </div>
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">پیشرفت ریالی</span>
            <span className="font-medium">{progress ?? 0}%</span>
          </div>
          <Progress value={progress ?? 0} className="h-2" />
        </div>
        {employer && <p className="text-sm text-muted-foreground">کارفرما: {employer}</p>}
      </CardContent>
      <CardFooter>
        <Button 
          variant="outline" 
          className="w-full" 
          onClick={() => onViewDetails?.(id)}
          data-testid={`button-view-project-${id}`}
        >
          مشاهده جزئیات
          <ArrowLeft className="w-4 h-4 mr-2" />
        </Button>
      </CardFooter>
    </Card>
  );
}
