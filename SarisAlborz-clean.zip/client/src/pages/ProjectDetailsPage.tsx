import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowRight, Calendar, DollarSign, MapPin, Building2, FileText, TrendingUp } from "lucide-react";
import type { Project } from "@shared/schema";
import { toPersianDigits } from "@/lib/persian-utils";

const statusLabels: Record<string, string> = {
  active: "در حال اجرا",
  completed: "تکمیل شده",
  pending: "در انتظار",
  suspended: "متوقف شده",
};

const statusVariants: Record<string, "default" | "outline" | "destructive"> = {
  active: "default" as const,
  completed: "default" as const,
  pending: "outline" as const,
  suspended: "destructive" as const,
};

export default function ProjectDetailsPage() {
  const { id } = useParams();
  const [, setLocation] = useLocation();

  const { data: projects = [], isLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const response = await fetch("/api/projects");
      if (!response.ok) throw new Error("خطا در دریافت پروژه‌ها");
      return response.json();
    },
  });

  const project = projects.find((p) => p.id === id);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <p className="text-muted-foreground">در حال بارگذاری...</p>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="flex flex-col items-center justify-center h-96 gap-4">
        <p className="text-muted-foreground">پروژه مورد نظر یافت نشد</p>
        <Button onClick={() => setLocation("/projects")}>
          <ArrowRight className="w-4 h-4 ml-2" />
          بازگشت به لیست پروژه‌ها
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-3xl font-bold">{project.title}</h1>
            <Badge variant={statusVariants[project.status || "active"]}>
              {statusLabels[project.status || "active"]}
            </Badge>
          </div>
          <p className="text-muted-foreground">
            شماره قرارداد: {project.contractNumber || "نامشخص"}
          </p>
        </div>
        <Button variant="outline" onClick={() => setLocation("/projects")}>
          <ArrowRight className="w-4 h-4 ml-2" />
          بازگشت
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">پیشرفت پروژه</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{toPersianDigits(project.progress || 0)}%</div>
            <Progress value={project.progress || 0} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">مبلغ قرارداد</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {project.amount ? `${project.amount} ریال` : "نامشخص"}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">محل پروژه</CardTitle>
            <MapPin className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{project.location || "نامشخص"}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">تاریخ شروع</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {project.startDate ? toPersianDigits(project.startDate) : "نامشخص"}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="info" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="info">اطلاعات کلی</TabsTrigger>
          <TabsTrigger value="reports">گزارش‌ها</TabsTrigger>
          <TabsTrigger value="files">فایل‌ها و اسناد</TabsTrigger>
        </TabsList>

        <TabsContent value="info" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>جزئیات پروژه</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <Building2 className="w-5 h-5 text-muted-foreground mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">کارفرما</p>
                      <p className="text-sm text-muted-foreground">
                        {project.employer || "نامشخص"}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <FileText className="w-5 h-5 text-muted-foreground mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">شماره قرارداد</p>
                      <p className="text-sm text-muted-foreground">
                        {project.contractNumber || "نامشخص"}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <MapPin className="w-5 h-5 text-muted-foreground mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">محل اجرا</p>
                      <p className="text-sm text-muted-foreground">
                        {project.location || "نامشخص"}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <Calendar className="w-5 h-5 text-muted-foreground mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">تاریخ شروع</p>
                      <p className="text-sm text-muted-foreground">
                        {project.startDate ? toPersianDigits(project.startDate) : "نامشخص"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="font-medium mb-3">پیشرفت پروژه</h3>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>پیشرفت ریالی</span>
                    <span className="font-medium">{toPersianDigits(project.progress || 0)}%</span>
                  </div>
                  <Progress value={project.progress || 0} className="h-3" />
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="font-medium mb-3">اطلاعات مالی</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">مبلغ کل قرارداد</p>
                    <p className="text-lg font-bold">
                      {project.amount ? `${project.amount} ریال` : "نامشخص"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">وضعیت</p>
                    <Badge variant={statusVariants[project.status || "active"]} className="mt-1">
                      {statusLabels[project.status || "active"]}
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>گزارش‌های پروژه</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground text-center py-8">
                گزارشی برای این پروژه ثبت نشده است
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="files" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>فایل‌ها و اسناد</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground text-center py-8">
                فایلی برای این پروژه آپلود نشده است
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
