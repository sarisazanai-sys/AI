#!/bin/bash

echo "🚀 Starting SarisAlborz application setup..."

# Wait for PostgreSQL to be ready
echo "⏳ Waiting for PostgreSQL to be ready..."
until pg_isready -h localhost -p 5432 -U postgres; do
  sleep 1
done

echo "✅ PostgreSQL is ready!"

# Push database schema
echo "📊 Initializing database schema..."
npm run db:push

# Start the application
echo "🌟 Starting development server..."
npm run dev
